<?php 
session_start();
include('connect.php');

if(isset($_POST['btnSave']))
{
	$txtSubjectName=$_POST['txtSubjectName'];
	$txtLevelID=$_POST['txtLevelID'];

	$checkSubject="SELECT * FROM Subject
		 	Where SubjectName='$txtSubjectName'";
		 	
	$result=mysql_query($checkSubject);
	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('SubjectName $txtSubjectName already exist in Database.')</script>";
		echo "<script>window.location='SubjectRegister.php'</script>";
		exit();
	}

		$query="INSERT INTO Subject(SubjectName,LevelID)
		VALUES ('$txtSubjectName','$txtLevelID')";
	
	    $result=mysql_query($query);

		if($result) 
		{
			echo "<script>window.alert('Register sucessful')</script>";
			echo "<script>window.location='SubjectRegister.php'</script>";
		}
		else
		{
				echo "<p>Something wrong in Subject Register" . mysql_error() . "</p>";
		}
}
include('Header.php');
?>
<html>
<head>
<title>Subject Register</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>

<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="SubjectRegister.php" method="post">
<fieldset>
<legend>Enter Subject Information:</legend>

<table align="center" cellpadding="4px">

<tr>
	<td>Subject Name:</td>
	<td>
	<input type="text" name="txtSubjectName" placeholder="Eg.OOAD" required/>
	</td>
</tr>

<tr>
	<td>Level ID:</td>
	<td>
	<input type="text" name="txtLevelID" placeholder="Eg.1" required/>
	</td>
</tr>

<tr>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
<hr></hr>
<fieldset>
<legend>Subject List:</legend>
<?php  
$query="SELECT * FROM Subject";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Subject Data Found.</p>";
	exit();
}
?>

<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>SubjectID</th>
	<th>SubjectName</th>
	<th>LevelID</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$SubjectID=$array[0];
	$SubjectName=$array['SubjectName'];
	$LevelID=$array['LevelID'];

	echo "<tr>";
		echo "<td>$SubjectID</td>";
		echo "<td>$SubjectName</td>";
		echo "<td>$LevelID</td>";
		echo "<td>
			  <a href=SubjectUpdate.php?SubjectID=$SubjectID>Edit</a> |
			  <a href='SubjectDelete.php?SubjectID=$SubjectID'>Delete</a>
			  </td>";
	echo "</tr>";
}
?>
</table>
</fieldset>

</form>
</body>
</html>
<?php 
include ('Footer.php');
?>