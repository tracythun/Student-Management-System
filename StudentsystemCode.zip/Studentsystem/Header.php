<?php 
session_start();
include('connect.php');
?>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edgez">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/superslides.css">
    <link href="css/slick.css" rel="stylesheet">  
    <link rel='stylesheet prefetch' href='https://cdn.rawgit.com/pguso/jquery-plugin-circliful/master/css/jquery.circliful.css'>  
    <link rel="stylesheet" href="css/animate.css"> 
    <link rel="stylesheet" href="css/queryLoader.css" type="text/css" />
    <link type="text/css" media="all" rel="stylesheet" href="css/jquery.tosrus.all.css" />    
    <link id="switcher" href="css/themes/default-theme.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>   
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>    

    <script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
    <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
    <script type="text/javascript" src="DataTables/datatables.min.js"></script>
  </head>

  <body>
    <a class="scrollToTop" href="#"></a>
    <header id="header">
      <div class="menu_area">
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation"> 
          <div class="container">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                  <span class="sr-only">Toggle navigation</span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                  <span class="icon-bar"></span>
                </button>

                <img src="SchoolImages/KMD_Logo.png">

            </div>  
 
             <div class="col-ld-3  col-md-3 col-sm-3">
              <div class="single_footer_widget">
                <ul class="footer_social">
                  <li><a data-toggle="tooltip" data-placement="top" title="Facebook" class="soc_tooltip" href="https://www.facebook.com/kmd.com.mm/"><i class="fa fa-facebook"></i></a></li>
                  <li><a data-toggle="tooltip" data-placement="top" title="Twitter" class="soc_tooltip"  href="https://twitter.com/intent/tweet?original_referer=http%3A%2F%2Fwww.kmd.com.sg%2F&ref_src=twsrc%5Etfw&text=Home%20%7C%20KMD&tw_p=tweetbutton&url=http%3A%2F%2Fwww.kmd.com.sg%2F"><i class="fa fa-twitter"></i></a></li>
                  <li><a data-toggle="tooltip" data-placement="top" title="Google+" class="soc_tooltip"  href="https://plus.google.com/share?app=110&url=http%3A%2F%2Fwww.kmd.com.sg%2F"><i class="fa fa-google-plus"></i></a>
                  </li>
                </ul>
              </div>
            </div>

            <div id="navbar" class="navbar-collapse collapse">
              <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">

                <?php
                if(isset($_SESSION['AdminID']))
                {
                ?>
                <li><a href="TeacherList.php">Teachers</a></li>
                <li><a href="StudentList.php">Students</a></li>
                <li class="active"><a href="SectionRegister.php">Sections</a></li>
                <li><a href="LevelRegister.php">Levels</a></li>
                <li><a href="RoomRegister.php">Rooms</a></li>
                <li><a href="SubjectRegister.php">Subjects</a></li>
                <li><a href="EnrolmentList.php">Enrolments</a></li>
                <li><a href="CourseRegister.php">Courses</a></li>
                <li><a href="Attendance.php">Attendance</a></li>
                <li><a href="Logout.php">Logout</a></li>
                <li><a href="Admin Guide.pdf"><img src="SchoolImages/help.png"></a></li>
                
                <?php
                }
                else if(isset($_SESSION['StudentID']))
                {
                ?>
                  <li><a href="SubjectList.php">Subjects</a></li>
                  <li><a href="SectionList.php">Sections</a></li>
                  <li><a href="CourseList.php">Courses</a></li>
                  <li><a href="LevelList.php">Levels</a></li>  
                  <li><a href="RoomList.php">Rooms</a></li>
                  <li><a href="TeacherList.php">Teachers</a></li>
                  <li><a href="Logout.php">Logout</a></li>
                  <li><a href="User Guide.pdf"><img src="SchoolImages/help.png"></a></li>
                
                <?php
                }
                ?>
                  
                               
                </ul>  
              </div>
            </div>     
          </nav>  
        </div>

    </header>

    <section id="courseArchive">
      <div class="container">
        <div class="row">
        </div>
          
        <div class="imgBanner">
            <div class="row"></div>
        
</body>
</html>

