<?php
//session_start();
//include('connect.php');
include ('Header.php');
?>
<html>
<head>

<br/>
<br/>

<script>
function showUser(str) 
{
  if (str=="") 
  {
    document.getElementById("txtHint").innerHTML="";
    return;
  } 
  
  if (window.XMLHttpRequest) 
  {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } 
  else 
  { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }

  xmlhttp.onreadystatechange=function() 
  {
    if (this.readyState==4 && this.status==200) 
    {
      document.getElementById("txtHint").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","studentTable.php?q="+str,true);
  xmlhttp.send();
}
</script>
</head>

<body>
<form>

<select name="users" onchange="showUser(this.value)">
<option>Select Class:</option>
<?php
  echo    $all="select * from Section";
          $ret=mysql_query($all);
  echo    $count=mysql_num_rows($ret);

      for ($i=0;$i<$count;$i++) 
      { 
        $row=mysql_fetch_array($ret);
        echo  $ID=$row['SectionID'];
              $ST=$row['SectionType'];
          $T=$row['Time'];
        
        echo "<option value='$ID'>$ID - $ST ($T)</option>";
      }
?>

</select>
</form>

<br>
<div id="txtHint"><b>Student info will be listed here.</b></div>
</body>
</html>
<?php 
include ('Footer.php');
?>
