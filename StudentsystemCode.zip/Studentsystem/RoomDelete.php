<?php  
include('connect.php');

$RoomID=$_REQUEST['RoomID'];

$query="DELETE FROM Room WHERE RoomID='$RoomID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Room Successfully Deleted.')</script>";
	echo "<script>window.location='RoomRegister.php'</script>";
}
else
{
	echo "<p>Something wrong in RoomDelete" . mysql_error() . "</p>";
}
?>