<?php 
session_start();
include('connect.php');
if(isset($_POST['btnSave']))
{
	$txtEnrollID=$_POST['txtEnrollID'];
	$txtDate=$_POST['txtDate'];
	$txtPaymentAmount=$_POST['txtPaymentAmount'];
	$txtDepositAmount=$_POST['txtDepositAmount'];
	$rdoCardType=$_POST['rdoCardType'];
	$txtAccount=$_POST['txtAccount'];
	
	$checkPayment="SELECT * FROM Payment
	            	Where EnrollID='$txtEnrollID'";
	$result=mysql_query($checkPayment);
	$count=mysql_num_rows($result);

	if ($count!=0)
	{
		echo "<script>window.alert('EnrollID $txtEnrollID already exist in Database.')</script>";
		echo "<script>window.location='Payment.php'</script>";
		exit();
	}

		$query="INSERT INTO `Payment`(`EnrollID`,`Date`,`PaymentAmount`,`DepositAmount`,`CardType`,`Account`)
		        VALUES ('$txtEnrollID','$txtDate','$txtPaymentAmount','$txtDepositAmount','$rdoCardType','$txtAccount')";

    	$result=mysql_query($query);
    	
		if($result)
		{
			echo "<script>window.alert('Payment sucessful!!')</script>";
			echo "<script>window.location='Payment.php'</script>";
		}
		else
		{
			echo "<p>Something wrong in Payment" . mysql_error() . "</p>";
		}
}	
include('Header.php');
?>
<html>
<head>
<title>Payment</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css"/>
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>

</head>

<body>
<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="Payment.php" method="post">

<fieldset>
<legend>Enter Payment Information:</legend>

<table align="center" cellpadding="4px">
<tr>
	<td>Enroll ID:</td>
	<td>
		<input type="text" name="txtEnrollID">
	</td>
</tr>
		
<tr>
	<td>Date:</td>
	<td>
		<input type="date" name="txtDate" id="Date">
    </td>
</tr>

<tr>
	<td>Payment Amount:</td>
	<td>
	<input type="text" name="txtPaymentAmount" required/>
	</td>	
</tr>

<tr>
	<td>Deposit Amount:</td>
	<td>
	<input type="text" name="txtDepositAmount" required/>
	</td>
</tr>
	
<tr>
	<td>Card Type:</td>
	<td>
	<input type="radio" name="rdoCardType" value="Mastercard"/>Mastercard
	<img src='SchoolImages/mastercard.jpg'/>
	<input type="radio" name="rdoCardType" value="MyanPay"/>MyanPay
	<img src='SchoolImages/MyanPay.png'/>
	</td>
</tr>

<tr>
	<td>Account:</td>
	<td>
		<input type="text" name="txtAccount" />
	</td>
</tr>


<tr>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset"  value="Cancel"/>
	</td>
</tr>

</table>
</fieldset>

</form>
</body>
</html>

<?php 
include('Footer.php');
?>