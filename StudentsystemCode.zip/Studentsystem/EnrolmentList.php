<?php 
include('connect.php');
session_start();
include('Header.php');

?>

<html>
<head>
<fieldset>
<legend>Enrolment:</legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  
$query="SELECT * FROM Enrolment";
$result=mysql_query($query);
$count=mysql_num_rows($result);
?>

<br>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>EnrollID</th>
	<th>EnrollDate</th>
	<th>StudentID</th>
	<th>TotalAmount</th>
	<th>DepositAmount</th>
	<th>CardType</th>
	<th>Account</th>
	<th>LevelName</th>
	<th>SectionID</th>
	<th>Action</th>
</tr>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$EnrollID=$array[0];
	$EnrollDate=$array['EnrollDate'];
	$StudentID=$array['StudentID'];
	$TotalAmount=$array['TotalAmount'];
	$DepositAmount=$array['DepositAmount'];
	$CartType=$array['CartType'];
	$Account=$array['Account'];
	$LevelName=$array['LevelName'];
	$SectionID=$array['SectionID'];
	
	echo "<tr>";
		echo "<td>$EnrollID</td>";
		echo "<td>$EnrollDate</td>";
		echo "<td>$StudentID</td>";
		echo "<td>$TotalAmount</td>";
		echo "<td>$DepositAmount</td>";
		echo "<td>$CartType</td>";
		echo "<td>$Account</td>";
		echo "<td>$LevelName</td>";
		echo "<td>$SectionID</td>";

	echo "<td>
			  <a href='EnrolmentDelete.php?EnrollID=$EnrollID'>Delete</a>
	    </td>";

	echo "</tr>";
}
?>
</tbody>
</table>
</body>
</fieldset>
</html>
<?php 
include ('Footer.php');
?>
