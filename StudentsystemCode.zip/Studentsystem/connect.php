<?php  
$host="localhost";
$user="root";
$pass="";
$database="student_db";

$connection=mysql_connect($host,$user,$pass)
or die("Cannot connect to Database");
mysql_select_db($database);
?>