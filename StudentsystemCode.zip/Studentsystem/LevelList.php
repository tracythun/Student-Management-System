<?php 
include('connect.php');
session_start();
include('Header.php');
?>

<html>
<head>
<fieldset>
<legend>Level List:</legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  
$query="SELECT * FROM Level";
$result=mysql_query($query);
$count=mysql_num_rows($result);
?>

<br>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>LevelID</th>
	<th>LevelName</th>
	<th>Duration</th>
	<th>Fee</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$LevelID=$array[0];
	$LevelName=$array['LevelName'];
	$Duration=$array['Duration'];
	$Fee=$array['Fee'];
	
	echo "<tr>";
		echo "<td>$LevelID</td>";
		echo "<td>$LevelName</td>";
		echo "<td>$Duration</td>";
		echo "<td>$Fee</td>";
		
	echo "</tr>";
}
?>
</tbody>
</table>
</body>
</fieldset>
</html>
<?php 
include('Footer.php');
?>


