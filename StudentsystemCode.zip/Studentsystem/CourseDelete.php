<?php  
include('connect.php');

$CourseID=$_REQUEST['CourseID'];

$query="DELETE FROM Course WHERE CourseID='$CourseID'";
$result=mysql_query($query);

if($result) //True 
{
	echo "<script>window.alert('Course Successfully Deleted.')</script>";
	echo "<script>window.location='CourseRegister.php'</script>";
}
else
{
	echo "<p>Something wrong in CourseDelete" . mysql_error() . "</p>";
}
?>