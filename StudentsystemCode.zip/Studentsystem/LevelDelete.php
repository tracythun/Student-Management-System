<?php  
include('connect.php');

$LevelID=$_REQUEST['LevelID'];

$query="DELETE FROM Level WHERE LevelID='$LevelID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Level Successfully Deleted.')</script>";
	echo "<script>window.location='LevelRegister.php'</script>";
}
else
{
	echo "<p>Something wrong in LevelDelete" . mysql_error() . "</p>";
}
?>