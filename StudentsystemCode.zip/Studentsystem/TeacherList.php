<?php 
include('connect.php');
session_start();
include('Header.php');

?>

<html>
<head>
<fieldset>
<legend>Teachers:</legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  
$query="SELECT * FROM Teacher";
$result=mysql_query($query);
$count=mysql_num_rows($result);
?>

<br>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>Teacher Name</th>
	<th>Nationality</th>
	<th>Gender</th>
	<th>Age</th>
	<th>Qualification</th>
	<th>Email</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$TeacherName=$array['TeacherName'];
	$Nationality=$array['Nationality'];
	$Gender=$array['Gender'];
	$Age=$array['Age'];
	$Qualification=$array['Qualification'];
	$Email=$array['Email'];
		
	echo "<tr>";
		echo "<td>$TeacherName</td>";
		echo "<td>$Nationality</td>";
		echo "<td>$Gender</td>";
		echo "<td>$Age</td>";
		echo "<td>$Qualification</td>";
		echo "<td>$Email</td>";
	echo "</tr>";
}
?>
</tbody>
</table>
</body>
</fieldset>
</html>
<?php 
include ('Footer.php');
?>