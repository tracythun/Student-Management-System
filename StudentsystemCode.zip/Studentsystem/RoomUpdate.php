<?php  
session_start();
include('connect.php');

if(isset($_REQUEST['RoomID'])) 
{
	$RoomID=$_REQUEST['RoomID'];

	$query="SELECT * FROM Room WHERE RoomID='$RoomID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$RoomNo=$array['RoomNo'];
	$Floor=$array['Floor'];
	$RoomType=$array['RoomType'];
}
else
{
	$RoomID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtRoomID=$_POST['txtRoomID'];
	$txtRoomNo=$_POST['txtRoomNo'];
	$txtFloor=$_POST['txtFloor'];
	$txtRoomType=$_POST['txtRoomType'];

	$query="UPDATE Room
			SET RoomNo='$txtRoomNo',
			Floor='$txtFloor',
			RoomType='$txtRoomType'
			WHERE RoomID='$txtRoomID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Room Successfully Updated.')</script>";
		echo "<script>window.location='RoomRegister.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Room Update" . mysql_error() . "</p>";
	}
}
include('Header.php');
?>
<html>
<head>
	<title>Room Update</title>
</head>
<body>
<form action="RoomUpdate.php" method="post">
<fieldset>
<legend>Enter Room Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtRoomID" value="<?php echo $RoomID ?>">
<tr>
	<td>RoomNo</td>
	<td>
	<input type="text" name="txtRoomNo" value="<?php echo $RoomNo ?>" required/>
	</td>
</tr>
<tr>
	<td>Floor</td>
	<td>
	<input type="text" name="txtFloor" value="<?php echo $Floor ?>" required/>
	</td>
</tr>
<tr>
	<td>RoomType</td>
	<td>
	<input type="text" name="txtRoomType" value="<?php echo $RoomType ?>" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>

<?php 
include('Footer.php');
?>