<?php
session_start();
if(isset($_SESSION['StudentID']))
{
	session_unset($_SESSION['StudentID']);
}
elseif (isset($_SESSION['TeacherID'])) 
{
	session_unset($_SESSION['TeacherID']);
}
else
{
	session_destroy();

}
echo "<script>
	alert('Session Expired. Login again');
	location.assign('Login.php');
</script>";
?>
