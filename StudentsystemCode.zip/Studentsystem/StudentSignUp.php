<?php 
session_start();
include('connect.php');

if(isset($_POST['btnSave']))
{
	$txtStudentName=$_POST['txtStudentName'];
	$txtAge=$_POST['txtAge'];
	$rdogender=$_POST['rdogender'];
	$txtAddress=$_POST['txtAddress'];
	$txtDOB=$_POST['txtDOB'];
	$txtPhone=$_POST['txtPhone'];	
	$txtEmail=$_POST['txtEmail'];
	$txtPassword=$_POST['txtPassword'];

	$checkStudent="SELECT * FROM Student 
				WHERE StudentName='$txtStudentName'";
	$result=mysql_query($checkStudent);
	$count=mysql_num_rows($result); 

	if($count!=0) 
	{
		echo "<script>window.alert('Student Name $txtStudentName already exist.')</script>";
		echo "<script>window.location='StudentSignUp.php'</script>";
		exit();
	}

	$query="INSERT INTO `Student` (`StudentName`, `Age`, `Gender`, `Address`, `DOB`, `Phone`, `Email`,`Password`)
	        VALUES ('$txtStudentName','$txtAge','$rdogender','$txtAddress','$txtDOB','$txtPhone','$txtEmail','$txtPassword')";
	$result=mysql_query($query);

	if($result)
	{
		echo "<script>window.alert('Signup sucessful')</script>";
		echo "<script>window.location='CourseList.php'</script>";
	}
	
	else
	{
		echo "<p>Something is wrong in Student Signup" . mysql_error() . "</p>";
		exit();
	}
}
include ('Header.php');
?>
<html>
<head>
	<title>Student Signup</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/datepicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/datepicker.js" type="text/javascript"></script>
</head>


<body>

<form action="StudentSignup.php" method="post">
<fieldset>
<legend>Enter Student Info:</legend>
<table align="center" cellpadding="7px">
<tr>
	<td>Email</td>
	<td>
	<input type="email" name="txtEmail" placeholder="Eg.example@email.com" required/>
	</td>
</tr>

<tr>
	<td>Password</td>
	<td>
	<input type="password" name="txtPassword" placeholder="XXX" required/>
	</td>
</tr>

<tr>
	<td>Student Name:</td>
	<td>
	<input type="text" name="txtStudentName" placeholder="Eg.Victoria" required/>
	</td>
</tr>
<tr>
	<td>Age:</td>
	<td>
	<input type="text" name="txtAge" placeholder="Eg.15 " required/>
	</td>
</tr>

<tr>
	<td>Gender</td>
	<td>
	<input type="radio" name="rdogender" value="M" checked/> Male
	<input type="radio" name="rdogender" value="F"/>Female
	</td>
</tr>

<tr>
	<td>DOB</td>
	<td>
		<input type="date" name="txtDOB" id="dateofbirth">
	</td>
</tr>
<tr>
	<td>Phone</td>
	<td>
	<input type="text" name="txtPhone" placeholder="Eg.95+----------" required/>
	</td>
</tr>

<tr>
	<td>Address</td>
	<td>
	<input type="text" name="txtAddress" placeholder="[No./Street/Township]" required/>
	</td>
</tr>

<tr>
	<td>
	<a href="Login.php">Login?</a>
	</td>

<tr>
	<td></td>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	
	<input type="reset"  value="Cancel"/>
	</td>
</tr>

</table>
</fieldset>

</form>
</body>
</html>
<?php 
include ('Footer.php');
?>