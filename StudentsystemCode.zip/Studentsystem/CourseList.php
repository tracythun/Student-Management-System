<?php 
include('connect.php');
session_start();
include('Header.php');

$OpenDate='txtOpenDate';
?>

<html>
<head>
<fieldset>
<legend>Course List:</legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  
$query="SELECT * FROM Course";
$result=mysql_query($query);
$count=mysql_num_rows($result);
?>

<br>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>CourseID</th>
	<th>CourseName</th>
	<th>Description</th>
	<th>Click Here</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$CourseID=$array[0];
	$CourseName=$array['CourseName'];
	$Description=$array['Description'];
	
	echo "<tr>";
		echo "<td>$CourseID</td>";
		echo "<td>$CourseName</td>";
		echo "<td>$Description</td>";
		echo "<td>
				<a href='ViewList.php?CourseName=$CourseName'>Open Date</a>";
	echo "</tr>";
}
?>
</tbody>

</table>
</body>
</fieldset>
</html>
<?php 
include ('Footer.php');
?>
