<?php  
include('connect.php');

$SubjectID=$_REQUEST['SubjectID'];

$query="DELETE FROM Subject WHERE SubjectID='$SubjectID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Subject Successfully Deleted.')</script>";
	echo "<script>window.location='SubjectRegister.php'</script>";
}
else
{
	echo "<p>Something wrong in SubjectDelete" . mysql_error() . "</p>";
}
?>