<?php  
session_start();
include('connect.php');

if(isset($_REQUEST['LevelID'])) 
{
	$LevelID=$_REQUEST['LevelID'];

	$query="SELECT * FROM Level WHERE LevelID='$LevelID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$LevelName=$array['LevelName'];
	$Duration=$array['Duration'];
	$Fee=$array['Fee'];
}
else
{
	$LevelID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtLevelID=$_POST['txtLevelID'];
	$txtLevelName=$_POST['txtLevelName'];
	$txtDuration=$_POST['txtDuration'];
	$txtFee=$_POST['txtFee'];

	$query="UPDATE Level
			SET LevelName='$txtLevelName',
			Duration='$txtDuration',
			Fee='$txtFee'
			WHERE LevelID='$txtLevelID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Level Successfully Updated.')</script>";
		echo "<script>window.location='LevelRegister.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Level Update" . mysql_error() . "</p>";
	}
}
include('Header.php');
?>
<html>
<head>
	<title>Level Update</title>
</head>
<body>
<form action="LevelUpdate.php" method="post">
<fieldset>
<legend>Enter Level Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtLevelID" value="<?php echo $LevelID ?>">
<tr>
	<td>LevelName</td>
	<td>
	<input type="text" name="txtLevelName" value="<?php echo $LevelName?>" required/>
	</td>
</tr>
<tr>
	<td>Duration</td>
	<td>
	<input type="text" name="txtDuration" value="<?php echo $Duration?>" required/>
	</td>
</tr>

<tr>
	<td>Fee</td>
	<td>
	<input type="text" name="txtFee" value="<?php echo $Fee?>" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>
<?php 
include('Footer.php');
?>