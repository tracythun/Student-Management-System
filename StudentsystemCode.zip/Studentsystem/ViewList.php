<?php 
include('connect.php');
session_start();
include('Header.php');

if(isset($_GET['CourseName']))
{
	$CourseName=$_GET['CourseName'];
}

$query="SELECT * FROM Level l,Section s
		Where s.levelID=l.levelID";
$result=mysql_query($query);
$count=mysql_num_rows($result);


?>

<html>
<head>
<fieldset>
<legend></legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  


?>

Course-
<?php echo $CourseName ?>


<br>
<table id="tableid" border="2" class="display">
<thead>

<tr align="left">
	<th>LevelName</th>
	<th>SectionID</th>
	<th>Time</th>
	<th>StartDate</th>
	<th>Action</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$LevelName=$array['LevelName'];
	$SectionID=$array['SectionID'];
	$Time=$array['Time'];
	$StartDate=$array['StartDate'];
	$LevelID=$array['LevelID'];

	
	echo "<tr>";
		echo "<td>$LevelName</td>";
		echo "<td>$SectionID</td>";
		echo "<td>$Time</td>";
		echo "<td>$StartDate</td>";
		echo "<td>
			<a href='Enrolment.php?LevelName=$LevelName&SectionID=$SectionID&Level=$LevelID'>Enroll</a>
			
		</td>";
	echo "</tr>";
}
?>
</tbody>

</table>
</body>
</fieldset>
</html>
<?php 
include ('Footer.php');
?>
