<?php 
session_start();
include('connect.php');

if(isset($_POST['btnSave']))
{
	$txtTeacherName=$_POST['txtTeacherName'];
	$txtAddress=$_POST['txtAddress'];
	$txtNationality=$_POST['txtNationality'];
	$rdogender=$_POST['rdogender'];
	$txtAge=$_POST['txtAge'];	
	$txtDOB=$_POST['txtDOB'];
	$txtWorkingHours=$_POST['txtWorkingHours'];
	$txtQualification=$_POST['txtQualification'];
	$txtPhone=$_POST['txtPhone'];
	$txtEmail=$_POST['txtEmail'];

	$checkTeacher="SELECT * FROM Teacher
		 	Where TeacherName='$txtTeacherName'";

	$result=mysql_query($checkTeacher);
	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('TeacherName $txtTeacherName already exist in Database.')</script>";
		echo "<script>window.location='TeacherRegister.php'</script>";
		exit();
	}

	$query="INSERT INTO Teacher(TeacherName,Address,Nationality,Gender,Age,DOB,WorkingHours, Qualification,Phone,Email)
    VALUES ('$txtTeacherName','$txtAddress','$txtNationality','$rdogender','$txtAge','$txtDOB','$txtWorkingHours','$txtQualification','$txtPhone','$txtEmail')";

    $result=mysql_query($query);

	if($result)
	{
		echo "<script>window.alert('Register sucessful')</script>";
		echo "<script>window.location='TeacherRegister.php'</script>";	
	}
	else
	{
		echo "<p>Something wrong in Teacher Register" . mysql_error() . "</p>";
	}
}
include ('Header.php');
?>
<html>
<head>
<title>Teacher Register</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>
</head>

<body>
<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="TeacherRegister.php" method="post">
<fieldset>
<legend>Enter Teacher Information:</legend>

<table align="center" cellpadding="7px">

<tr>
	<td>Teacher Name:</td>
	<td>
	<input type="text" name="txtTeacherName" placeholder="Eg.Bill Nye" required/>
	</td>
</tr>

<tr>
	<td>Address:</td>
	<td>
	<input type="textarea" name="txtAddress" placeholder="Eg.No.15,Wall Street,New York" required></text>
	</td>
</tr>

<tr>
	<td>Nationality</td>
	<td>
	<input type="text" name="txtNationality" placeholder="Eg.Myanmar" required/>
	</td>
</tr>

<tr>
	<td>Gender</td>
	<td>
	<input type="radio" name="rdogender" value="M" checked/> Male
	<input type="radio" name="rdogender" value="F"/>Female
	</td>
</tr>

<tr>
	<td>Age:</td>
	<td>
	<input type="text" name="txtAge" placeholder="Eg.15" required/>
	</td>
</tr>

<tr>
	<td>DOB</td>
	<td>
	<input type="date" name="txtDOB" id="dateofbirth">
    </td>
</tr>

<tr>
	<td>Working Hours</td>
	<td>
	<input type="text" name="txtWorkingHours" placeholder="Eg.9-12" required/>
	</td>
</tr>

<tr>
	<td>Qualification</td>
	<td>
	<input type="text" name="txtQualification" required/>
	</td>
</tr>

<tr>
	<td>Phone</td>
	<td>
	<input type="text" name="txtPhone" placeholder="Eg.95+" required/>
	</td>
</tr>

<tr>
	<td>Email</td>
	<td>
	<input type="email" name="txtEmail" placeholder="Eg.harry@gmail.com" required/>
	</td>
</tr>
	
<tr>
	<td></td>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
<hr></hr>
<fieldset>
<legend>Teacher List:</legend>
<?php 
$query="SELECT * FROM Teacher";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Teacher Data Found.</p>";
	exit();
}
?>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>TeacherID</th>
	<th>TeacherName</th>
	<th>Address</th>
	<th>Nationality</th>
	<th>Gender</th>
	<th>Age</th>
	<th>DOB</th>
	<th>WorkingHours</th>
	<th>Qualification</th>
	<th>Phone</th>
	<th>Email</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$TeacherID=$array[0];
	$TeacherName=$array['TeacherName'];
	$Address=$array['Address'];
	$Nationality=$array['Nationality'];
	$Gender=$array['Gender'];
	$Age=$array['Age'];
	$DOB=$array['DOB'];
	$WorkingHours=$array['WorkingHours'];
	$Qualification=$array['Qualification'];
	$Phone=$array['Phone'];
	$Email=$array['Email'];

	echo "<tr>";
		echo "<td>$TeacherID</td>";
		echo "<td>$TeacherName</td>";
		echo "<td>$Address</td>";
		echo "<td>$Nationality</td>";
		echo "<td>$Gender</td>";
		echo "<td>$Age</td>";
		echo "<td>$DOB</td>";
		echo "<td>$WorkingHours</td>";
		echo "<td>$Qualification</td>";
		echo "<td>$Phone</td>";
		echo "<td>$Email</td>";
		echo "<td>

			  <a href=TeacherUpdate.php?TeacherID=$TeacherID>Edit</a>|
			  <a href='TeacherDelete.php?TeacherID=$TeacherID'>Delete</a>
			  </td>";
	echo "</tr>";
}
?>
</tbody>
</table>

</fieldset>

</form>
</body>

</html>
<?php 
include('Footer.php');
?>