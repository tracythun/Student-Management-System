<?php 
session_start();
include('connect.php');

if(isset($_POST['btnSave']))
{	
	$txtTime=$_POST['txtTime'];
	$txtStartDate=$_POST['txtStartDate'];
	$cboRoomID=$_POST['cboRoomID'];
	$cboLevelID=$_POST['cboLevelID'];
	$txtSectionType=$_POST['txtSectionType'];

	$checkSection="SELECT * FROM Section
		 	Where RoomID='$cboRoomID'";
	$result=mysql_query($checkSection);
	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('$cboRoomID already exist in Database.')</script>";
		echo "<script>window.location='SectionRegister.php'</script>";
		exit();
	}

		$query="INSERT INTO `Section`(`Time`,`StartDate`,`RoomID`,`LevelID`,`SectionType`)
		VALUES ('$txtTime','$txtStartDate','$cboRoomID','$cboLevelID','$txtSectionType')";
	
	    $result=mysql_query($query);

		if($result) 
		{
			echo "<script>window.alert('Register sucessful')</script>";
			echo "<script>window.location='SectionRegister.php'</script>";
		}
		else
		{
				echo "<p>Something wrong in SectionRegister" . mysql_error() . "</p>";
		}
}
include ('Header.php');
?>

<html>
<head>
<title>Section Register</title>
<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>
</head>

<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>


<form action="SectionRegister.php" method="post">
<fieldset>
<legend>Enter Section Information:</legend>

<table align="center" cellpadding="4px">

<tr>
	<td>Time:</td>
	<td>
	<input type="text" name="txtTime" placeholder="Eg.8:00-12:00" required/>
	</td>
</tr>

<tr>
	<td>Start Date:</td>
	<td>	
    <input type="date" name="txtStartDate" id="StartDate">
    </td>
</tr>

<tr>
	<td>Room ID:</td>
	<td>		
	<select name="cboRoomID">
	<option>Choose Room ID:</option>
	<?php  
	$query="SELECT * FROM Room";
	$result=mysql_query($query);
	$count=mysql_num_rows($result);

	for($i=0;$i<$count;$i++) 
	{ 
		$array=mysql_fetch_array($result);
		$RoomID=$array['RoomID'];
		$RoomType=$array['RoomType'];
		echo "<option value='$RoomID'>$RoomID - $RoomType</option>";
	}
	?>
	</select>
	</td>
</tr>

<tr>
	<td>Level ID:</td>
	<td>
	<select name="cboLevelID">
	<option>Choose Level ID:</option>
	<?php  
	$query="SELECT * FROM Level";
	$result=mysql_query($query);
	$count=mysql_num_rows($result);

	for($i=0;$i<$count;$i++) 
	{ 
		$array=mysql_fetch_array($result); 
		$LevelID=$array['LevelID'];
		$LevelName=$array['LevelName'];
		echo "<option value='$LevelID'>$LevelID-$LevelName</option>";
	}
	?>
	</select>
	</td>
</tr>

<tr>
	<td>Section Type:</td>
	<td>	
	<input type="text" name="txtSectionType" required/>
	</td>
</tr>

<tr>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>

</table>
</fieldset>

<hr></hr>

<fieldset>
<legend>Section List:</legend>

<?php  
$query="SELECT * FROM Section";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Section Data Found.</p>";
	exit();
}

?>

<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>Section ID</th>
	<th>Time</th>
	<th>Start Date</th>
	<th>Room ID</th>
	<th>Level ID</th>
	<th>Section Type</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$SectionID=$array[0];
	$Time=$array['Time'];
	$StartDate=$array['StartDate'];
	$RoomID=$array['RoomID'];
	$LevelID=$array['LevelID'];
	$SectionType=$array['SectionType'];

	echo "<tr>";
		echo "<td>$SectionID</td>";
		echo "<td>$Time</td>";
		echo "<td>$StartDate</td>";		
		echo "<td>$RoomID</td>";
		echo "<td>$LevelID</td>";
		echo "<td>$SectionType</td>";

		echo "<td>
			  <a href='SectionUpdate.php?SectionID=$SectionID'>Edit</a> |
			  <a href='SectionDelete.php?SectionID=$SectionID'>Delete</a>
			  </td>";
	echo "</tr>";
}
?> 
</tbody>

</table>
</fieldset>

</form>
</body>
</html>

<?php 
include('Footer.php');
?>