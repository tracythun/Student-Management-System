<?php 
session_start();

include('connect.php');
include ('Header.php');
?>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="StudentList.php" method="post">
<a href="StudentSignUp.php"></a>	
<fieldset>
<legend>Student List:</legend>
<?php  
$query="SELECT * FROM Student";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Student Data Found.</p>";
	exit();
}
?>

<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>StudentID</th>
	<th>StudentName</th>
	<th>Age</th>
	<th>Gender</th>
	<th>Address</th>
	<th>DOB</th>
	<th>Phone</th>
	<th>Email</th>
	<th>Password</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$StudentID=$array[0];
	$StudentName=$array['StudentName'];
	$Age=$array['Age'];
	$Gender=$array['Gender'];
	$Address=$array['Address'];
	$DOB=$array['DOB'];
	$Phone=$array['Phone'];
	$Email=$array['Email'];
	$Password=$array['Password'];
	
	echo "<tr>";
		echo "<td>$StudentID</td>";
		echo "<td>$StudentName</td>";
		echo "<td>$Age</td>";
		echo "<td>$Gender</td>";
		echo "<td>$Address</td>";
		echo "<td>$DOB</td>";
		echo "<td>$Phone</td>";
		echo "<td>$Email</td>";
		echo "<td>$Password</td>";
		echo "<td>
			  <a href='StudentUpdate.php?StudentID=$StudentID'>Edit</a> |
			  <a href='StudentDelete.php?StudentID=$StudentID'>Delete</a>
			  </td>";
	echo "</tr>";
}
?>
</table>
</fieldset>

</form>
<?php 
include ('Footer.php');
?>