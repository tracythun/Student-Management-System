<?php  
include('connect.php');

$StudentID=$_REQUEST['StudentID'];

$query="DELETE FROM Student WHERE StudentID='$StudentID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Student Successfully Deleted.')</script>";
	echo "<script>window.location='StudentList.php'</script>";
}
else
{
	echo "<p>Something wrong in StudentDelete" . mysql_error() . "</p>";
}
?>