<?php 
include('AutoID_Helper.php');
include('Header.php');

if(!isset($_SESSION["StudentID"]))
{
		echo "<script>window.alert('Please Login')</script>";
		echo "<script>window.location='Login.php'</script>";
}
else
{
	$StudentID=$_SESSION["StudentID"];

	if(isset($_GET["Level"]))
	{
		$Level=$_GET['Level'];

		 $sel="SELECT * from Level 
		      Where levelID='$Level'";

		$ret=mysql_query($sel);
		$arr=mysql_fetch_array($ret);

		echo$fee=$arr['Fee'];
	}
	else
	{
		$Level='';
	}
	

}

if(isset($_POST['btnEnroll']))
{
	$txtEnrollDate=$_POST['txtEnrollDate'];
	$txtStudentID=$_POST['txtStudentID'];
 	$txtTotalAmount=$_POST['txtTotalAmount'];
	$txtDepositAmount=$_POST['txtDepositAmount'];
	$txtLevelName=$_POST['txtLevelName'];
	$txtSectionID=$_POST['txtSectionID'];
	$rdoCardType=$_POST['rdoCardType'];
	$txtAccount=$_POST['txtAccount'];
	$txtEnrollID=$_POST['txtEnrollID'];

	$checkEnrolment="SELECT * FROM Enrolment
		 	Where StudentID='$txtStudentID'";

	$result=mysql_query($checkEnrolment);

	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('StudentID $txtStudentID already exist in Database.')</script>";
		echo "<script>window.location='CourseList.php'</script>";
		exit();
	}

		$query="INSERT INTO Enrolment(EnrollID,EnrollDate,StudentID,TotalAmount,DepositAmount,LevelName,SectionID,CardType,Account)
		VALUES ('$txtEnrollID','$txtEnrollDate','$txtStudentID','$txtTotalAmount','$txtDepositAmount','$txtLevelName','$txtSectionID','$rdoCardType','$txtAccount')";
	
	    $result=mysql_query($query);

		if($result) 
		{
			echo "<script>window.alert('Enrolment Successful!')</script>";
			echo "<script>window.location='CourseList.php'</script>";
		}
		else
		{
			echo "<p>Something wrong in Enrolment" . mysql_error() . "</p>";
		}
}

?>
<html>
<head>
<title>Enrolment</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>
</head>



<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>


<form action="Enrolment.php" method="post">
<fieldset>
<legend>Enter Enrolment Information:</legend>

<table align="center" cellpadding="4px">

<tr>
	<td>EnrollID:</td>
	<td>
	<input type="text" name="txtEnrollID" value="<?php echo AutoID('Enrolment','EnrollID','ER-00000',6) ?>">
	</td>
</tr>


<tr>
	<td>EnrollDate:</td>
	<td>
	<input type="date" name="txtEnrollDate" id="EnrollDate">
	</td>
</tr>

<tr>
	<td>StudentID:</td>
	<td>
	<input type="text" name="txtStudentID" value="<?php echo $StudentID ?>"required/>
	</td>
</tr>


<tr>
	<td>TotalAmount:</td>
	<td>
	<input type="text" name="txtTotalAmount" value="<?php echo $fee ?>" readonly/>
	</td>
</tr>


<tr>
	<td>DepositAmount:</td>
	<td>
	<input type="text" name="txtDepositAmount" min="100000"required/>
	</td>
</tr>
<tr>
	<td>Card Type:</td>
	<td>
	<input type="radio" name="rdoCardType" value="Mastercard"/>Mastercard
	<img src='SchoolImages/mastercard.jpg'/>
	<input type="radio" name="rdoCardType" value="MyanPay"/>MyanPay
	<img src='SchoolImages/MyanPay.png'/>
	</td>
</tr>

<tr>
	<td>Account:</td>
	<td>
		<input type="text" name="txtAccount" />
	</td>
</tr>


<tr>
	<td>LevelName:</td>
	<td>
	<input type="text" name="txtLevelName" value="<?php echo $_GET['LevelName'] ?>" readonly />
	</td>
</tr>
<tr>
	<td>SectionID:</td>
	<td>
	<input type="text" name="txtSectionID" value="<?php echo $_GET['SectionID'] ?>" readonly/>
	</td>
</tr>

<tr>
	<td>
	<input type="submit" name="btnEnroll" value="Enroll"/>
	<input type="reset" name="btnCancel" value="Cancel"/>
	</td>
</tr>
</table>
</fieldset>


</table>
</form>
</body>
</html>
<?php 
include('Footer.php');
?>