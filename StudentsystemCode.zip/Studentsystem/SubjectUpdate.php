<?php
session_start();

include('connect.php');

if(isset($_REQUEST['SubjectID'])) 
{
	$SubjectID=$_REQUEST['SubjectID'];

	$query="SELECT * FROM Subject WHERE SubjectID='$SubjectID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$SubjectName=$array['SubjectName'];
	$LevelID=$array['LevelID'];
}
else
{
	$SubjectID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtSubjectID=$_POST['txtSubjectID'];
	$txtSubjectName=$_POST['txtSubjectName'];
	$txtLevelID=$_POST['txtLevelID'];

	$query="UPDATE Subject
			SET SubjectName='$txtSubjectName',
			LevelID='$txtLevelID'
			WHERE SubjectID='$txtSubjectID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Subject Successfully Updated.')</script>";
		echo "<script>window.location='SubjectRegister.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Subject Update" . mysql_error() . "</p>";
	}
}
include ('Header.php');
?>
<html>
<head>
	<title>Subject Update</title>
</head>
<body>
<form action="SubjectUpdate.php" method="post">
<fieldset>
<legend>Enter Subject Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtSubjectID" value="<?php echo $SubjectID ?>">
<tr>
	<td>SubjectName</td>
	<td>
	<input type="text" name="txtSubjectName" value="<?php echo $SubjectName ?>" required/>
	</td>
</tr>

<tr>
	<td>Level ID</td>
	<td>
	<input type="text" name="txtLevelID" value="<?php echo $LevelID ?>" required/>
	</td>
</tr>
<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Cancel"/>
	</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>
<?php 
include('Footer.php');
?>