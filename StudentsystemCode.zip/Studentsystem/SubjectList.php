<?php 
include('connect.php');
session_start();
include('Header.php');
?>

<html>
<head>
<fieldset>
<legend>Subject List:</legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  
$query="SELECT * FROM Subject";
$result=mysql_query($query);
$count=mysql_num_rows($result);
?>

<br>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>SubjectID</th>
	<th>SubjectName</th>
	<th>LevelID</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);
	$SubjectID=$array[0];
	$SubjectName=$array['SubjectName'];
	$LevelID=$array['LevelID'];
		
	echo "<tr>";
		echo "<td>$SubjectID</td>";
		echo "<td>$SubjectName</td>";
		echo "<td>$LevelID</td>";
	echo "</tr>";
}
?>
</tbody>
</table>
</body>
</fieldset>
</html>
<?php 
include ('Footer.php');
?>