<?php
session_start();
include ('connect.php'); 

if(isset($_POST['btnLogin']))
{
	$txtEmail=$_POST['txtEmail'];
	$txtPassword=$_POST['txtPassword'];

    function AdminLogin($txtEmail,$txtPassword)
    {
	   $txtEmail=$txtEmail;
	   $txtPassword=$txtPassword;
	
    	$query="SELECT * FROM Admin
	       		WHERE Email='$txtEmail'
			    AND Password='$txtPassword'";

	    $result=mysql_query($query);
	    $count=mysql_num_rows($result);
	    $arr=mysql_fetch_array($result);
	
	    if($count==0) 
	    {
		  // echo "<script>window.alert('Email or Password Incorrect.')</script>";
		  //echo "<script>window.location='Customer_Login.php'</script>";
	    }
	    else
	    {
		  $_SESSION['AdminID']=$arr['AdminID'];
		  $_SESSION['AdminName']=$arr['AdminName'];
		
		  echo "<script>window.alert('Success:You are Login as Admin.')</script>";
		  echo "<script>window.location='SectionRegister.php'</script>";
	    }
    }		
	
    $query="Select * from Student
	        where Email='$txtEmail'
		    and Password='$txtPassword'";

	$ret=mysql_query($query,$connection);

	$num_results=mysql_num_rows($ret);
	$row=mysql_fetch_array($ret);
	
	if($num_results<=0) 
	{
		AdminLogin($txtEmail,$txtPassword);
	}
	else 
	{
		$_SESSION["Email"]=$row["Email"];
		$_SESSION["StudentID"]=$row["StudentID"];

		echo "<script>window.alert('Success: You are Login as Student.')</script>";
		echo "<script>window.location='CourseList.php'</script>";
	}
}	
?>

<script>
function myFunction()
{
    var txt;
    var person = prompt("Please enter your name:", "Harry Potter");
    if (person == null || person == "") {
        txt = "User cancelled the prompt.";
    } else {
        txt = "Hello " + person + "! How are you today?";
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css"/>

<style>
html, body 
{   
    width: 100%;   
    height: 100%;   
    font-family: "Helvetica Neue", Helvetica, sans-serif;   
    color: #444;   
    -webkit-font-smoothing: antialiased; background:url(SchoolImages/image2.jpeg) no-repeat center;
}

#container 
{
    position: fixed;
    width: 340px;
    height: 30px;
    top: 50%;
    left: 50%;
    margin-top: -140px;
    margin-left: -170px;
}

a
{
    color:orange;
    font-family: "Verdana";
    font-size:18px;
    margin-left: 18px;
    padding-top: 12px;
}

b
{   
    color:black;
    display: inline-block;
    margin-left: 18px;
    padding-top: 12px;
    font-size: 14px;
}
form
{
   margin: 0 auto;
   margin-top: 20px;
}

label 
{
    color: #f50808;
    display: inline-block;
    margin-left: 18px;
    padding-top: 12px;
    font-size: 14px;
}

legend
{
    color: #128ca5;
    display: inline-block;
    margin-left: 18px;
    padding-top: 10px;
    font-size: 20px;
}

p a
{
    font-size: 11px;
    color: red;
    float: right;
    margin-top: -13px;
    margin-right: 20px;
}

p a:hover 
{
    color: #555;
}

input 
{
    font-family: "Verdana";
    font-size: 15px;
    outline: none;
}

input[type=email],
input[type=password] 
{
    color: #777;
    padding-left: 10px;
    margin: 10px;
    margin-top: 12px;
    margin-left: 18px;
    width: 290px;
    height: 35px;
}

#lower
{
    background: #afdafe;
    width: 100%;
    height: 96px;
    margin-top: 20px;
}

input[type=submit]
{
    float: right;
    margin-right: 20px;
    margin-top: 20px;
    width: 80px;
    height: 30px;

    background: #fff;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);

}

#container
{
    position: fixed;
    width: 325px;
    height: 324px;
    top: 50%;
    left: 52%;
    margin-top: -140px;
    margin-left: -170px;
    background: #fff;
    border-radius: 3px;
    border: 1px solid #ccc;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .1);

    border: 1px solid #04225e;
    border-radius: 2px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #04225e;
}

input[type=Email] 
{
    color:grey;
    padding-left: 10px;
    margin: 10px;
    margin-top: 12px;
    margin-left: 18px;
    width: 290px;
    height: 35px;
    border: 1px solid #c7d0d2;
    border-radius: 2px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
}


input[type=password] 
{
    color: #777;
    padding-left: 10px;
    margin: 10px;
    margin-top: 12px;
    margin-left: 18px;
    width: 290px;
    height: 35px;
    border: 1px solid #c7d0d2;
    border-radius: 2px;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
}


input[type=submit] 
{
    float: right;
    margin-right: 20px;
    margin-top: -30px;
    width: 80px;
    height: 30px;
    font-size: 14px;
    font-weight: bold;
    color:black;
    background-color: #acd6ef; /*IE fallback*/
    background-image: -webkit-gradient(linear, left top, left bottom, from(#acd6ef), to(#6ec2e8));
    background-image: -moz-linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    background-image: linear-gradient(top left 90deg, #acd6ef 0%, #6ec2e8 100%);
    border-radius: 30px;
    border: 1px solid #6eddf5;
    box-shadow: 0 1px 2px rgba(0, 0, 0, .3), inset 0 1px 0 rgba(255, 255, 255, .5);
    cursor: pointer;
}
</style>
</head>


<form action="Login.php" method="post">
<div id="container">
<legend>Enter Login Info:</legend>
<br/>

	<label>Email</label>
    <input type="Email" name="txtEmail" placeholder="Eg.thomas20@gmail.com" required/>
       	       
    <label>Password</label>
    <input type="password" name="txtPassword" placeholder="XXXXXXXXXXX" required />
        	 
    <div id="lower">

    <b>Don't have account?</b>
    <br/>
    <a href="StudentSignup.php">Register!</a>

    <br/>
    
    <input type="submit" name="btnLogin" value="Login">
    </div>
</div>
</form>
</body>

</html>
