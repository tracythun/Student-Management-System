<?php 
include('connect.php');
session_start();
include('Header.php');
?>

<html>
<head>
<fieldset>
<legend>Room List:</legend>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

</head>
<body>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<?php  
$query="SELECT * FROM Room";
$result=mysql_query($query);
$count=mysql_num_rows($result);
?>

<br>
<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>RoomID</th>
	<th>RoomNo</th>
	<th>Floor</th>
	<th>RoomType</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$RoomID=$array[0];
	$RoomNo=$array['RoomNo'];
	$Floor=$array['Floor'];
	$RoomType=$array['RoomType'];
	
	echo "<tr>";
		echo "<td>$RoomID</td>";
		echo "<td>$RoomNo</td>";
		echo "<td>$Floor</td>";
		echo "<td>$RoomType</td>";
		
	echo "</tr>";
}
?>
</tbody>
</table>
</fieldset>
</body>
</html>
<?php 
include ('Footer.php');
?>
