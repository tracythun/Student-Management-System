<?php  
session_start();
include('connect.php');

if(isset($_REQUEST['StudentID'])) 
{
	$StudentID=$_REQUEST['StudentID'];

	$query="SELECT * FROM Student WHERE StudentID='$StudentID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$StudentName=$array['StudentName'];
	$Age=$array['Age'];
	$Gender=$array['Gender'];
	$Address=$array['Address'];
	$DOB=$array['DOB'];
	$Phone=$array['Phone'];
	$Email=$array['Email'];
	$Password=$array['Password'];
}
else
{
	$StudentID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtStudentID=$_POST['txtStudentID'];
	$txtStudentName=$_POST['txtStudentName'];
	$txtAge=$_POST['txtAge'];
	$rdogender=$_POST['rdogender'];
	$txtAddress=$_POST['txtAddress'];
	$txtDOB=$_POST['txtDOB'];
	$txtPhone=$_POST['txtPhone'];
	$txtEmail=$_POST['txtEmail'];
	$txtPassword=$_POST['txtPassword'];
	
	
	$query="UPDATE Student
			SET StudentName='$txtStudentName',
			Age='$txtAge',
			Gender='$rdogender',
			Address='$txtAddress',
			DOB='$txtDOB',
			Phone='$txtPhone',
			Email='$txtEmail',
			Password='$txtPassword'

			WHERE StudentID='$txtStudentID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Student Successfully Updated.')</script>";
		echo "<script>window.location='StudentList.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Student Update" . mysql_error() . "</p>";
	}
}
include('Header.php');
?>
<html>
<head>
	<title>Student Update</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>
</head>

</head>
<body>
<form action="StudentUpdate.php" method="post">
<fieldset>
<legend>Enter Student Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtStudentID" value="<?php echo $StudentID ?>">
<tr>
	<td>StudentName</td>
	<td>
	<input type="text" name="txtStudentName" value="<?php echo $StudentName ?>" required/>
	</td>
</tr>
<tr>
	<td>Age</td>
	<td>
	<input type="text" name="txtAge" value="<?php echo $Age ?>" required</text>
	</td>
</tr>

<tr>
	<td>Gender</td>
	<td>
	<input type="radio" name="rdogender" value="M" checked value="<?php echo $Gender ?>"/> Male
	<input type="radio" name="rdogender" value="F" checked value="<?php echo $Gender ?>" />Female
	</td>
</tr>

<tr>
	<td>Address</td>
	<td>
	<input type="textarea" name="txtAddress" value="<?php echo $Address ?>" required/>
	</td>
</tr>

<tr>
	<td>DOB</td>
	<td>
	     <input type="date" name="txtDOB" id="dateofbirth" value="<?php echo $DOB ?>" required/>
    </td>
</tr>

<tr>
	<td>Phone</td>
	<td>
	<input type="text" name="txtPhone" value="<?php echo $Phone ?>" required/>
	</td>
</tr>


<tr>
	<td>Email</td>
	<td>
	<input type="text" name="txtEmail" value="<?php echo $Email ?>" required/>
	</td>
</tr>


<tr>
	<td>Password</td>
	<td>
	<input type="text" name="txtPassword" value="<?php echo $Password ?>" required/>
	</td>
</tr>


<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>
<?php 
include('Footer.php');
?>