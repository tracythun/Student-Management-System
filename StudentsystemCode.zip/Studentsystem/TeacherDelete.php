<?php  
include('connect.php');

$TeacherID=$_REQUEST['TeacherID'];

$query="DELETE FROM Teacher WHERE TeacherID='$TeacherID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Teacher Successfully Deleted.')</script>";
	echo "<script>window.location='TeacherRegister.php'</script>";
}
else
{
	echo "<p>Something wrong in TeacherDelete" . mysql_error() . "</p>";
}
?>