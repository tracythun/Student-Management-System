<?php  
session_start();
include('connect.php');

if(isset($_REQUEST['CourseID'])) 
{
	$CourseID=$_REQUEST['CourseID'];

	$query="SELECT * FROM Course WHERE CourseID='$CourseID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$CourseName=$array['CourseName'];
	$Description=$array['Description'];
}
else
{
	$CourseID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtCourseID=$_POST['txtCourseID'];
	$txtCourseName=$_POST['txtCourseName'];
	$txtDescription=$_POST['txtDescription'];

	$query="UPDATE Course
			SET CourseName='$txtCourseName',
			Description='$txtDescription'
			WHERE CourseID='$txtCourseID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Course Successfully Updated.')</script>";
		echo "<script>window.location='CourseRegister.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Course Update" . mysql_error() . "</p>";
	}
}
include('Header.php');
?>
<html>
<head>
	<title>Course Update</title>
</head>
<body>
<form action="CourseUpdate.php" method="post">
<fieldset>
<legend>Enter Course Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtCourseID" value="<?php echo $CourseID ?>">
<tr>
	<td>CourseName</td>
	<td>
	<input type="text" name="txtCourseName" value="<?php echo $CourseName ?>" required/>
	</td>
</tr>
<tr>
	<td>Description</td>
	<td>
	<input type="text" name="txtDescription" value="<?php echo $Description ?>" required/>
	</td>
</tr>
<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>
<?php 
include('Footer.php');
?>