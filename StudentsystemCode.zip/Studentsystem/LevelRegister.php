<?php 
session_start();
include('connect.php');

include('Header.php');
if(isset($_POST['btnSave']))
{
	$txtLevelName=$_POST['txtLevelName'];
	$txtDuration=$_POST['txtDuration'];
	$txtFee=$_POST['txtFee'];

	$checkLevel="SELECT * FROM Level 
				Where LevelName='$txtLevelName'";
	$result=mysql_query($checkLevel);
	$count=mysql_num_rows($result);

	if ($count!=0)
	{
		echo "<script>window.alert('LevelName $txtLevelName already exist in Database.')</script>";
		echo "<script>window.location='LevelRegister.php'</script>";
		exit();
	}

		$query="INSERT INTO `Level`(`LevelName`, `Duration`,`Fee`)
	        VALUES ('$txtLevelName','$txtDuration','$txtFee')";
	
		$result=mysql_query($query);

		if($result)		
		{
			echo "<script>window.alert('Register sucessful!')</script>";
			echo "<script>window.location='LevelRegister.php'</script>";
		}
		else
		{
			echo "<p>Something is wrong in LevelRegister" . mysql_error() . "</p>";
		}
}
?>
<html>
<head>
<title>Level Register</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>

<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="LevelRegister.php" method="post">

<fieldset>
<legend>Enter Level Information:</legend>

<table align="center" cellpadding="4px">

<tr>
	<td>Level Name:</td>
	<td>
	<input type="text" name="txtLevelName" placeholder="Eg.First year" required/>
	</td>
</tr>

<tr>
	<td>Duration:</td>
	<td>
	<input type="text" name="txtDuration" placeholder="Eg.1 year" required/>
	</td>
</tr>

<tr>
	<td>Fee</td>
	<td>
	<input type="text" name="txtFee" placeholder="Eg.100000 kyats" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset"  value="Cancel"/>
	</td>
</tr>
</table>
</fieldset>	

<hr></hr>
<fieldset>
<legend>Level List:</legend>

<?php  
$query="SELECT * FROM Level";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Level Data Found.</p>";
	exit();
}
?>

<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>LevelID</th>
	<th>LevelName</th>
	<th>Duration</th>
	<th>Fee</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$LevelID=$array[0];
	$LevelName=$array['LevelName'];
	$Duration=$array['Duration'];
	$Fee=$array['Fee'];

	echo "<tr>";
		echo "<td>$LevelID</td>";
		echo "<td>$LevelName</td>";
		echo "<td>$Duration</td>";
		echo "<td>$Fee</td>";
		echo "<td>
			  <a href='LevelUpdate.php?LevelID=$LevelID'>Edit</a>| 
			  <a href='LevelDelete.php?LevelID=$LevelID'>Delete</a>
			  </td>";
	echo "</tr>";
}
?>
</tbody>
</table>
</fieldset>

</form>
</body>
</html>

<?php 
include('Footer.php');
?>
