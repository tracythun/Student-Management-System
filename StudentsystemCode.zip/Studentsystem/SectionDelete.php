<?php  
include('connect.php');

$SectionID=$_REQUEST['SectionID'];

$query="DELETE FROM Section WHERE SectionID='$SectionID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Section Successfully Deleted.')</script>";
	echo "<script>window.location='SectionRegister.php'</script>";
}
else
{
	echo "<p>Something wrong in SectionDelete" . mysql_error() . "</p>";
}
?>
