<?php 
session_start();
include('connect.php');

if(isset($_POST['btnSave']))
{
	$txtRoomNo=$_POST['txtRoomNo'];
	$txtFloor=$_POST['txtFloor'];
	$txtRoomType=$_POST['txtRoomType'];

	$checkRoom="SELECT * FROM Room
		 		Where RoomNo='$txtRoomNo'";
	$result=mysql_query($checkRoom);
	$count=mysql_num_rows($result);
	
	if ($count!=0)
	{
		echo "<script>window.alert('RoomID $txtRoomID already exist in Database.')</script>";
		echo "<script>window.location='RoomRegister.php'</script>";
		exit();
	}

	$query="INSERT INTO `Room`(`RoomNo`,`Floor`,`RoomType`)
	        VALUES ('$txtRoomNo','$txtFloor','$txtRoomType')";

    $result=mysql_query($query);
		
	if($result)
	{
		echo "<script>window.alert('Register sucessful!')</script>";
		echo "<script>window.location='RoomRegister.php'</script>";
	}
	else
	{
		echo "<p>Something is wrong in Room Register".mysql_error()."</p>";
	}
}
include('Header.php');
?>
<html>
<head>
<title>Room Register</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
<script type="text/javascript" src="DataTables/datatables.min.js"></script>
</head>

<body>
<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="RoomRegister.php"method="post">

<fieldset>
<legend>Enter Room Information:</legend>

<table align="center" cellpadding="4px">

<tr>
	<td>RoomNo:</td>
	<td>
	<input type="text" name="txtRoomNo" placeholder="Eg.5" required/>
	</td>
</tr>

<tr>
	<td>Floor:</td>
	<td>
	<input type="text" name="txtFloor" placeholder="Eg.2" required/>
	</td>
</tr>

<tr>
	<td>RoomType:</td>
	<td>
	<input type="text" name="txtRoomType" placeholder="Eg.Library" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset" value="Cancel"/>
	</td>
</tr>

</table>
</fieldset>
<hr></hr>

<fieldset>
<legend>Room List:</legend>
<?php  
$query="SELECT * FROM Room";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Room Data Found.</p>";
	exit();
}
?>

<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>RoomID</th>
	<th>RoomNo</th>
	<th>Floor</th>
	<th>RoomType</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for($i=0;$i<$count;$i++)	
	{
		$array=mysql_fetch_array($result);

		$RoomID=$array[0];
		$RoomNo=$array['RoomNo'];
		$Floor=$array['Floor'];
		$RoomType=$array['RoomType'];

		echo "<tr>";
			echo "<td>$RoomID</td>";
			echo "<td>$RoomNo</td>";
			echo "<td>$Floor</td>";
			echo "<td>$RoomType</td>";

			echo "<td>
			    <a href='RoomUpdate.php?RoomID=$RoomID'>Edit</a>|
			    <a href='RoomDelete.php?RoomID=$RoomID'>Delete</a>
			</td>";
		echo "</tr>";
	}
?>
</tbody>
</table>
</fieldset>

</form>
</body>
</html>
<?php 
include('Footer.php');
?>