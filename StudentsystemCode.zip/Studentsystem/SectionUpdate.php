<?php  
session_start();
include('connect.php');

if(isset($_REQUEST['SectionID'])) 
{
	$SectionID=$_REQUEST['SectionID'];

	$query="SELECT * FROM Section WHERE SectionID='$SectionID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$Time=$array['Time'];
	$StartDate=$array['StartDate'];
	$RoomID=$array['RoomID'];
	$LevelID=$array['LevelID'];
	$SectionType=$array['SectionType'];
}
else
{
	$SectionID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtSectionID=$_POST['txtSectionID'];
	$txtTime=$_POST['txtTime'];
	$txtStartDate=$_POST['txtStartDate'];
	$cboRoomID=$_POST['cboRoomID'];
	$cboLevelID=$_POST['cboLevelID'];
	$txtSectionType=$_POST['txtSectionType'];

	$query="UPDATE Section
			SET Time='$txtTime',
			StartDate='$txtStartDate',
			RoomID='$cboRoomID',
			LevelID='$cboLevelID',
			SectionType='$txtSectionType'
			WHERE SectionID='$txtSectionID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Section Successfully Updated.')</script>";
		echo "<script>window.location='SectionRegister.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Section Update" . mysql_error() . "</p>";
	}
}
include('Header.php');
?>
<html>
<head>
	<title>Section Update</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>

</head>
<body>
<form action="SectionUpdate.php" method="post">
<fieldset>
<legend>Enter Section Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtSectionID" value="<?php echo $SectionID ?>">
<tr>
	<td>Time</td>
	<td>
	<input type="text" name="txtTime" value="<?php echo $Time?>" required/>
	</td>
</tr>
<tr>
	<td>StartDate</td>
	<td>
	<input type="date" name="txtStartDate" id="StartDate" value="<?php echo $StartDate?>" required/>
	</td>
</tr>

<tr>
	<td>RoomID</td>
	<td>		
	<select name="cboRoomID">
	<option>Choose Room ID</option>
	<?php  
	$query="SELECT * FROM Room";
	$result=mysql_query($query);
	$count=mysql_num_rows($result);

	for($i=0;$i<$count;$i++) 
	{ 
		$array=mysql_fetch_array($result);
		$RoomID=$array['RoomID'];

		echo "<option value='$RoomID'>$RoomID</option>";
	}
	?>
	</select>
	</td>	
</tr>

<tr>
	<td>LevelID</td>
	<td>		
	<select name="cboLevelID">
	<option>Choose Level ID</option>
	<?php  
	$query="SELECT * FROM Level";
	$result=mysql_query($query);
	$count=mysql_num_rows($result);

	for($i=0;$i<$count;$i++) 
	{ 
		$array=mysql_fetch_array($result);
		$LevelID=$array['LevelID'];

		echo "<option value='$LevelID'>$LevelID</option>";
	}
	?>
	</select>
	</td>	
</tr>

<tr>
	<td>SectionType</td>
	<td>
	<input type="text" name="txtSectionType" value="<?php echo $SectionType ?>" required/>
	</td>
</tr>
<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>

</form>
</body>
</html>

<?php 
include('Footer.php');
?>