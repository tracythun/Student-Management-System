<?php  
session_start();
include('connect.php');

if(isset($_REQUEST['TeacherID'])) 
{
	$TeacherID=$_REQUEST['TeacherID'];

	$query="SELECT * FROM Teacher WHERE TeacherID='$TeacherID'";
	$result=mysql_query($query);
	$array=mysql_fetch_array($result);

	$TeacherName=$array['TeacherName'];
	$Address=$array['Address'];
	$Nationality=$array['Nationality'];
	$Gender=$array['Gender'];
	$Age=$array['Age'];
	$DOB=$array['DOB'];
	$WorkingHours=$array['WorkingHours'];
	$Qualification=$array['Qualification'];
	$Phone=$array['Phone'];
	$Email=$array['Email'];
}
else
{
	$TeacherID="";
}

if(isset($_POST['btnUpdate'])) 
{
	$txtTeacherID=$_POST['txtTeacherID'];
	$txtTeacherName=$_POST['txtTeacherName'];
	$txtAddress=$_POST['txtAddress'];
	$txtNationality=$_POST['txtNationality'];
	$rdogender=$_POST['rdogender'];
	$txtAge=$_POST['txtAge'];
	$txtDOB=$_POST['txtDOB'];
	$txtWorkingHours=$_POST['txtWorkingHours'];
	$txtQualification=$_POST['txtQualification'];
	$txtPhone=$_POST['txtPhone'];
	$txtEmail=$array['txtEmail'];
	
	
	$query="UPDATE Teacher
			SET TeacherName='$txtTeacherName',
			Address='$txtAddress',
			Nationality='$txtNationality',
			Gender='$rdogender',
			Age='$txtAge',
			DOB='$txtDOB',
			WorkingHours='$txtWorkingHours',
			Qualification='$txtQualification',
			Phone='$txtPhone',
			Email='$txtEmail'

			WHERE TeacherID='$txtTeacherID'";
	$result=mysql_query($query);
	
	if($result)
	{
		echo "<script>window.alert('Teacher Successfully Updated.')</script>";
		echo "<script>window.location='TeacherRegister.php'</script>";
	}
	else
	{
		echo "<p>Something wrong in Teacher Update" . mysql_error() . "</p>";
	}
}
include('Header.php');
?>
<html>
<head>
	<title>Teacher Update</title>

<script type="text/javascript" src="js/jquery-3.1.1.slim.min.js"></script>
<link href="script/DatePicker/DatePicker.css" rel="stylesheet" type="text/css" />
<script src="script/DatePicker/DatePicker.js" type="text/javascript"></script>

</head>
<body>
<form action="TeacherUpdate.php" method="post">
<fieldset>
<legend>Enter Teacher Information:</legend>
<table align="center" cellpadding="4px">
<input type="hidden" name="txtTeacherID" value="<?php echo $TeacherID ?>">

<tr>
	<td>TeacherName</td>
	<td>
	<input type="text" name="txtTeacherName" value="<?php echo $TeacherName ?>" required/>
	</td>
</tr>
<tr>
	<td>Address</td>
	<td>
	<input type="textarea" name="txtAddress" value="<?php echo $Address ?>" required/>
	</td>
</tr>

<tr>
	<td>Nationality</td>
	<td><input type="text" name="txtNationality" value="<?php echo $Nationality ?>" required/>
	</td>
</tr>

<tr>
	<td>Gender</td>
	<td>
	<input type="radio" name="rdogender" value="M" checked/>Male
	<input type="radio" name="rdogender" value="F" checked/>Female
	</td>
</tr>

<tr>
	<td>Age</td>
	<td>
	<input type="text" name="txtAge" value="<?php echo $Age?>" required/>
	</td>
</tr>

<tr>
	<td>DOB</td>
	<td>
		<input type="date" name="txtDOB" id="dateofbirth" value="<?php echo $DOB?>" required/>
	</td>
</tr>


<tr>
	<td>WorkingHours</td>
	<td>
	<input type="text" name="txtWorkingHours" value="<?php echo $WorkingHours ?>" required/>
	</td>
</tr>


<tr>
	<td>Qualification</td>
	<td>
	<input type="text" name="txtQualification" value="<?php echo $Qualification ?>" required/>
	</td>
</tr>


<tr>
	<td>Phone</td>
	<td>
	<input type="text" name="txtPhone" value="<?php echo $Phone ?>" required/>
	</td>
</tr>

<tr>
	<td>Email</td>
	<td>
	<input type="text" name="txtEmail" value="<?php echo $Email ?>" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnUpdate" value="Update"/>
	<input type="reset"  value="Clear"/>
	</td>
</tr>
</table>
</fieldset>
</form>
</body>
</html>
<?php 
include ('Footer.php');
?>