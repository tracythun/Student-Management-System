<?php  
include('connect.php');

$EnrollID=$_REQUEST['EnrollID'];

$query="DELETE FROM Enrolment WHERE EnrollID='$EnrollID'";
$result=mysql_query($query);


if($result) //True 
{
	echo "<script>window.alert('Enrolment Successfully Deleted.')</script>";
	echo "<script>window.location='EnrolmentList.php'</script>";
}
else
{
	echo "<p>Something wrong in EnrolmentDelete" . mysql_error() . "</p>";
}
?>