<?php 
session_start();
include('connect.php');

if(isset($_POST['btnSave']))
{
	$txtCourseName=$_POST['txtCourseName'];
	$txtDescription=$_POST['txtDescription'];

	$checkCourse="SELECT * FROM Course
		 	      Where CourseName='$txtCourseName'";
	$result=mysql_query($checkCourse);
	$count=mysql_num_rows($result);
	
	if ($count!=0)	
	{
		echo "<script>window.alert('CourseName $txtCourseName already exist in Database.')</script>";
		echo "<script>window.location='CourseRegister.php'</script>";
		exit();
	}

		$query="INSERT INTO `Course`(`CourseName`, `Description`)
	        VALUES ('$txtCourseName','$txtDescription')";
	
    	$result=mysql_query($query);
	
		if($result)
		{
			echo "<script>window.alert('Register sucessful!')</script>";
			echo "<script>window.location='CourseRegister.php'</script>";
		}
		else
		{
			echo "<p>Something wrong in Course Register" . mysql_error() . "</p>";
		}
}
include ('Header.php');
?>
<html>

<head>
<title>Course Register</title>

<script type="text/javascript"src="js/jquery-3.1.1.slim.min.js"></script>
<link rel="stylesheet"type="text/css"href="DataTables/datatables.min.css"/>
<script type="text/javascript"src="DataTables/datatables.min.js"></script>

</head>

<body>
<script>
$(document).ready( function () 
{
	$('#tableid').DataTable();
} );
</script>

<form action="CourseRegister.php" method="post">
<fieldset>
<legend>Enter Course Information:</legend>

<table align="center" cellpadding="4px">

<tr>
	<td>Course Name:</td>
	<td>
	<input type="text" name="txtCourseName" placeholder="Eg.HND" required/>
	</td>
</tr>

<tr>
	<td>Description:</td>
	
	<td>
	<input type="text" name="txtDescription" placeholder="Eg.Diploma" required/>
	</td>
</tr>

<tr>
	<td>
	</td>
	<td>
	<input type="submit" name="btnSave" value="Save"/>
	<input type="reset"  value="Cancel"/>
	</td>
</tr>

</table>
</fieldset>

<hr></hr>
<fieldset>
<legend>Course List:</legend>

<?php  
$query="SELECT * FROM Course";
$result=mysql_query($query);
$count=mysql_num_rows($result);

if($count<1) 
{
	echo "<p>No Course Data Found.</p>";
	exit();
}
?>

<table id="tableid" border="2" class="display">
<thead>
<tr align="left">
	<th>CourseID</th>
	<th>CourseName</th>
	<th>Description</th>
	<th>Actions</th>
</tr>
</thead>

<tbody>
<?php  
for ($i=0;$i<$count;$i++) 
{ 
	$array=mysql_fetch_array($result);

	$CourseID=$array[0];
	$CourseName=$array['CourseName'];
	$Description=$array['Description'];

	echo "<tr>";
		echo "<td>$CourseID</td>";
		echo "<td>$CourseName</td>";
		echo "<td>$Description</td>";
		echo "<td>
			  <a href='CourseUpdate.php?CourseID=$CourseID'>Edit</a>| 
			  <a href='CourseDelete.php?CourseID=$CourseID'>Delete</a>
			  </td>";
	echo "</tr>";
}
?>
</tbody>
</table>
</fieldset>

</form>
</body>
</html>
<?php 
include('Footer.php');
?>